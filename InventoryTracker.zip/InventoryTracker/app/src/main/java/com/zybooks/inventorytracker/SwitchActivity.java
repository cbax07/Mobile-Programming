package com.zybooks.inventorytracker;

import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Switch;

import androidx.appcompat.widget.SwitchCompat;

public class SwitchActivity implements CompoundButton.OnCheckedChangeListener {

    Switch mySwitch = null;

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (isChecked) {
            // do something when check is selected
        } else {
            //do something when unchecked
        }
    }
}