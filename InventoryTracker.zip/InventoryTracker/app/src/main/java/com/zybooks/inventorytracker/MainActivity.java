package com.zybooks.inventorytracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;


public class MainActivity extends AppCompatActivity {
    //instantiate each object in the Layout to a variable
    private EditText username;
    private EditText password;
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    //instantiate the permission switch and set it to a value
    private Switch sms;
    private static final int SEND_SMS = 1;
    //First ERROR - can not figure out why getInstance cannot be used.
    public Account mAccount = Account.getInstance(getApplication());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        sms = findViewById(R.id.sms);
        username.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        sms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hasSMSPermissions(view);
            }
        });
    }
    //
    public void signup(View view) {
        String user = username.getText().toString();
        String pass = password.getText().toString();
        if (user.equals("") || pass.equals("")) {
            Toast.makeText(MainActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
        } else {
            LoginDatabase loginDB = new LoginDatabase(this);
            boolean dbInsert = loginDB.insertData(user, pass);
            Database homeDB = new Database(this, user);
            mAccount.addAccount(loginDB, homeDB);
            boolean accountInsert = mAccount.accountUserPass(user, pass);
            if (dbInsert & accountInsert) {
                Toast.makeText(MainActivity.this, "Registered!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, HomeActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(MainActivity.this, "Registration Failed, User Exist! Sign In Instead", Toast.LENGTH_SHORT).show();
            }
        }
    }
    //This method is similar to the the method above, check input parameters exist, then check for
    //a match. If a match is found, log in.
    public void signin(View view) {
        String user = username.getText().toString();
        String pass = password.getText().toString();
        LoginDatabase loginDB = new LoginDatabase(this);
        if (user.equals("") || pass.equals("")) {
            Toast.makeText(MainActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
        } else {
            if (loginDB.checkusernamepassword(user, pass)) {
                Toast.makeText(MainActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Successfully Signed In", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, HomeActivity.class);
                startActivity(intent);
            }
        }
    }

    // Output information depending on if the request is granted or not.
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == 1) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(MainActivity.this, "Successfull", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
    //************************TEST BELOW****************************************************
    public static class Account {
        private static Account sAccount;
        public final Map<LoginDatabase, Database> mAccount = new HashMap<>();
        Set<Database> userSet = new HashSet<Database>();
        //Account sAccount;
        //if the account does not exist, it can be created
        public static Account getInstance(Context context) {
            if (sAccount == null) {
                sAccount = new Account(context);
            }
            return sAccount;
        }

        //constructor
        private Account(Context context) {
        }

        public boolean addAccount(LoginDatabase accountCred, Database accountDetails) {
            mAccount.put(accountCred, accountDetails);
            return true;
        }
        //Checks if the account name exists
        public boolean accountUser(String user) {
            boolean exist = false;
            for (LoginDatabase key : mAccount.keySet()) {
                if (key.checkusername(user)) {
                    exist = true;
                }
            }
            return exist;
        }
        //Checks if the account password exists
        public boolean accountUserPass(String user, String password) {
            boolean exist = false;
            for (LoginDatabase key : mAccount.keySet()) {
                if (key.checkusernamepassword(user, password)) {
                    exist = true;
                }
            }
            return exist;
        }

        public void deleteAccount(LoginDatabase cred) {
            mAccount.remove(cred);
        }
    }
    //************************TEST BELOW****************************************************
    public class LoginDatabase extends SQLiteOpenHelper {
        public static final String DBNAME = "Login.db";
        public LoginDatabase(Context context) {
            super(context, DBNAME, null, 1);
        }
        //basic onCreate
        @Override
        public void onCreate(SQLiteDatabase MyDB) {
            MyDB.execSQL("create Table users(username TEXT primary key, password TEXT)");
        }
        //basic onUpgrade
        @Override
        public void onUpgrade(SQLiteDatabase MyDB, int oldVersion, int newVersion) {
            MyDB.execSQL("drop Table if exists users");
        }
        //Write vales to an object, then insert that object into the database and return true.
        public boolean insertData(String username, String password){
            SQLiteDatabase MyDB = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put("username", username);
            contentValues.put("password", password);
            long result = MyDB.insert("users", null,contentValues);
            if(result == -1){
                return false;
            } else {
                return true;
            }
        }
        //Checks if the username exists
        public boolean checkusername(String username){
            SQLiteDatabase MyDB = this.getWritableDatabase();
            Cursor cursor = MyDB.rawQuery("Select * from users where username = ?", new String[]{username});
            if(cursor.getCount() >0){
                return true;
            } else {
                return false;
            }
        }
        //Checks if the password exists
        public boolean checkusernamepassword(String username, String password){
            SQLiteDatabase MyDB = this.getWritableDatabase();
            Cursor cursor = MyDB.rawQuery("Select * from users where username = ? and password = ? ", new String[]{username, password});
            if(cursor.getCount() > 0){
                return true;
            } else {
                return false;
            }
        }
    }


    // Check to see if SEND_SMS permission has been granted
    private boolean hasSMSPermissions(View view) {
        String sendSMS = Manifest.permission.SEND_SMS;
        if (ContextCompat.checkSelfPermission(this, sendSMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[] { sendSMS }, 1);
            return false;
        }
        return true;
    }


}
