package com.zybooks.inventorytracker;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity {
    EditText username;
    EditText contact;
    EditText dob;
    Database db;
    Switch mySwitch;

    //When the app is first started,
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Intent intent = getIntent();
        db = new Database(this,"Home_DB");

        mySwitch = (Switch) findViewById(R.id.sms);
        mySwitch.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener) this);

        username.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        contact.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        dob.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    public void viewing(View view) {
        Cursor res = db.getdata();
        if (res.getCount() == 0) {
            Toast.makeText(HomeActivity.this, "No Entry Exist", Toast.LENGTH_SHORT).show();
            return;
        }
        StringBuilder buffer = new StringBuilder();
        while (res.moveToNext()) {
            buffer.append("Name: ").append(res.getString(0)).append("\n");
            buffer.append("Quantity: ").append(res.getString(1)).append("\n");
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this);
        builder.setCancelable(true);
        builder.setTitle("User Entries");
        builder.setMessage(buffer.toString());
        builder.show();
    }

    public void inserting(View view) {
        String nameInsert = username.getText().toString();
        String contactInsert = contact.getText().toString();

        Boolean checkinsertdata = db.insertuserdata(nameInsert, contactInsert);
        if (checkinsertdata) {
            Toast.makeText(HomeActivity.this, "Entry Inserted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(HomeActivity.this, "Entry Not Inserted", Toast.LENGTH_SHORT).show();
        }
    }

    public void updating(View view) {
        String nameInsert = username.getText().toString();
        String contactInsert = contact.getText().toString();

        Boolean checkupdatedata = db.updateuserdata(nameInsert, contactInsert);
        if (checkupdatedata) {
            Toast.makeText(HomeActivity.this, "Entry Updated!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(HomeActivity.this, "Entry Not Updated", Toast.LENGTH_SHORT).show();
        }
    }

    public void deleting(View view) {
        String nameInsert = username.getText().toString();
        Boolean checkdeletedata = db.deletedata(nameInsert);
        if (checkdeletedata) {
            Toast.makeText(HomeActivity.this, "Entry Deleted!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(HomeActivity.this, "Entry Not Deleted", Toast.LENGTH_SHORT).show();
        }
    }
    public void exit(View view){
        finish();
    }
}