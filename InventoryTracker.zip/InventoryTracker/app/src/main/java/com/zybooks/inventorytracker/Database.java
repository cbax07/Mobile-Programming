package com.zybooks.inventorytracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

//Create SQLite database for storing the inventory items once the user's login info has been verified
public class Database extends SQLiteOpenHelper {

    public Database(Context context, String USER_DB) {
        super(context, USER_DB, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create Table Userdetails (name TEXT primary key, quantity TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop Table if exists Userdetails");
    }

    public Boolean insertuserdata(String name, String quantity){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("quantity", quantity);
        long result=db.insert("Userdetails", null, contentValues);
        return result != -1;
    }
    public boolean checkusername(String name){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from Userdetails where name = ?", new String[]{name});
        return cursor.getCount() > 0;
    }

    public Boolean updateuserdata(String name, String quantity){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("quantity", quantity);
        Cursor cursor = db.rawQuery("Select * from Userdetails where name = ?", new String[]{name});
        if(cursor.getCount()>0) {

            long result = db.update("Userdetails", contentValues, "name=?", new String[]{name});
            return result != -1;

        } else {
            return false;
        }
    }

    public Boolean deletedata(String name){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from Userdetails where name = ?", new String[]{name});
        if(cursor.getCount()>0) {

            long result = db.delete("Userdetails", "name=?", new String[]{name});
            return result != -1;

        } else {
            return false;
        }
    }

    public Cursor getdata(){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select * from Userdetails", null);
    }
}
